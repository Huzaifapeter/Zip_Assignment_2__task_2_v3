﻿
using System;
using System.Collections.Generic;

public interface IBankAccount
{
    void Deposit(decimal amount);
    void Withdraw(decimal amount);
}

public interface ITransaction
{
    void ExecuteTransaction(decimal amount);
    void PrintTransaction();
}

public abstract class BankAccount : IBankAccount
{
    private string accountNumber;
    private string accountHolderName;
    private decimal balance;

    public string AccountNumber
    {
        get { return accountNumber; }
        set
        {
            if (!string.IsNullOrEmpty(value))
            {
                accountNumber = value;
            }
            else
            {
                Console.WriteLine("Invalid account number.");
            }
        }
    }

    public string AccountHolderName
    {
        get { return accountHolderName; }
        set
        {
            if (!string.IsNullOrEmpty(value))
            {
                accountHolderName = value;
            }
            else
            {
                Console.WriteLine("Invalid account holder name.");
            }
        }
    }

    public decimal Balance
    {
        get { return balance; }
        set
        {
            if (value >= 0)
            {
                balance = value;
            }
            else
            {
                Console.WriteLine("Invalid balance.");
            }
        }
    }

    public BankAccount(string name, string accnumber, decimal blnce)
    {
        AccountHolderName = name;
        AccountNumber = accnumber;
        Balance = blnce;
    }

    public abstract void DisplayAccountInfo();
    public abstract void Deposit(decimal amount);
    public abstract void Withdraw(decimal amount);
    public abstract void ExecuteTransaction(decimal amount);
    public abstract void PrintTransaction();
}

public class SavingsAccount : BankAccount, ITransaction
{
    public int InterestRate { get; set; }

    public SavingsAccount(string name, string accnumber, decimal blnce, int interestRate) : base(name, accnumber, blnce)
    {
        InterestRate = interestRate;
    }

    public override void DisplayAccountInfo()
    {
        Console.WriteLine("Account Information:");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder's Name: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }

    public override void Deposit(decimal amount)
    {
        decimal interest = amount * InterestRate / 100;
        Balance += amount + interest;
        Console.WriteLine($"Deposit of {amount} succeeded. Interest added: {interest}. New balance: {Balance}");
    }

    public override void Withdraw(decimal amount)
    {
        if (amount <= Balance)
        {
            Balance -= amount;
            Console.WriteLine($"{amount} has been withdrawn successfully.");
        }
        else
        {
            Console.WriteLine($"Insufficient funds. Withdrawal of {amount} not possible.");
        }
    }
    public void Withdraw(int amount, string transactionId)
    {
        Withdraw(amount);
        Console.WriteLine($"Transaction ID: {transactionId}");
    }
    public override void ExecuteTransaction(decimal amount)
    {
        if (amount > 0)
        {
            Deposit(amount);
            Console.WriteLine($"Transaction executed: Deposited {amount} to account {AccountNumber}.");
        }
        else if (amount < 0)
        {
            amount = Math.Abs(amount);
            Withdraw(amount);
            Console.WriteLine($"Transaction executed: Withdrew {amount} from account {AccountNumber}.");
        }
        else
        {
            Console.WriteLine("Invalid transaction amount.");
        }
    }

    public override void PrintTransaction()
    {
        Console.WriteLine($"Transaction details for account {AccountNumber}:");
        Console.WriteLine($"Account Holder: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }
}

public class CheckingAccount : BankAccount, ITransaction
{
    public CheckingAccount(string name, string accnumber, decimal blnce) : base(name, accnumber, blnce)
    {
    }

    public override void DisplayAccountInfo()
    {
        Console.WriteLine("Account Information:");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder's Name: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }

    public override void Deposit(decimal amount)
    {
        Balance += amount;
        Console.WriteLine($"Deposit of {amount} succeeded.New balance: {Balance}");
    }

    public override void Withdraw(decimal amount)
    {
        if (amount > Balance)
        {
            Console.WriteLine($"Insufficient funds. Withdrawal of {amount} not possible.");
        }
        else
        {
            Balance -= amount;
            Console.WriteLine($"{amount} has been withdrawn successfully.");
        }
    }

    public void Withdraw(int amount, string transactionId)
    {
        Withdraw(amount);
        Console.WriteLine($"Transaction ID: {transactionId}");
    }

    public override void ExecuteTransaction(decimal amount)
    {
        if (amount > 0)
        {
            Deposit(amount);
            Console.WriteLine($"Transaction executed: Deposited {amount} to account {AccountNumber}.");
        }
        else if (amount < 0)
        {
            amount = Math.Abs(amount);
            Withdraw(amount);
            Console.WriteLine($"Transaction executed: Withdrew {amount} from account {AccountNumber}.");
        }
        else
        {
            Console.WriteLine("Invalid transaction amount.");
        }
    }

    public override void PrintTransaction()
    {
        Console.WriteLine($"Transaction details for account {AccountNumber}:");
        Console.WriteLine($"Account Holder: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }
}

public class LoanAccount : BankAccount, ITransaction
{
    public decimal InterestRate { get; set; }

    public LoanAccount(string name, string accnumber, decimal blnce, decimal interestRate) : base(name, accnumber, blnce)
    {
        InterestRate = interestRate;
    }

    public override void DisplayAccountInfo()
    {
        Console.WriteLine("Account Information:");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder's Name: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }

    public override void Deposit(decimal amount)
    {
        Console.WriteLine("Deposits are not allowed for Loan accounts.");
    }

    public override void Withdraw(decimal amount)
    {
        decimal interest = Balance * InterestRate / 100;
        Balance += interest;
        Console.WriteLine($"Withdrawal of {amount} succeeded. Interest added: {interest}. New balance: {Balance}");
    }

    public override void ExecuteTransaction(decimal amount)
    {
        if (amount > 0)
        {
            Deposit(amount);
            Console.WriteLine($"Transaction executed: Deposited {amount} to account {AccountNumber}.");
        }
        else if (amount < 0)
        {
            amount = Math.Abs(amount);
            Withdraw(amount);
            Console.WriteLine($"Transaction executed: Withdrew {amount} from account {AccountNumber}.");
        }
        else
        {
            Console.WriteLine("Invalid transaction amount.");
        }
    }

    public override void PrintTransaction()
    {
        Console.WriteLine($"Transaction details for account {AccountNumber}:");
        Console.WriteLine($"Account Holder: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance}");
    }
}

public class Bank
{
    public List<BankAccount> BankAccounts { get; set; }

    public Bank()
    {
        BankAccounts = new List<BankAccount>();
    }

    public void AddAccount(BankAccount account)
    {
        BankAccounts.Add(account);
        Console.WriteLine($"Account {account.AccountNumber} has been added to the bank.");
    }

    public void DepositToAccount(string accountNumber, decimal amount)
    {
        foreach (var account in BankAccounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                account.Deposit(amount);
                break;
            }
        }
    }

    public void WithdrawFromAccount(string accountNumber, decimal amount)
    {
        foreach (var account in BankAccounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                account.Withdraw(amount);
                break;
            }
        }
    }

    public void DisplayBankInfo()
    {
        Console.WriteLine("Bank Information:");
        foreach (var account in BankAccounts)
        {
            account.DisplayAccountInfo();
            Console.WriteLine();
        }
    }

    public void ExecuteTransaction(string accountNumber, decimal amount)
    {
        foreach (var account in BankAccounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                account.ExecuteTransaction(amount);
                break;
            }
        }
    }

    public void PrintTransaction(string accountNumber)
    {
        foreach (var account in BankAccounts)
        {
            if (account.AccountNumber == accountNumber)
            {
                account.PrintTransaction();
                break;
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();

        CheckingAccount account1 = new CheckingAccount("Huzaifa", "1234567890", 1000);
        SavingsAccount account2 = new SavingsAccount("Hanzala", "9876543210", 2000, 3);
        LoanAccount account3 = new LoanAccount("Qasim", "5678901234", 1500, 5);

        bank.AddAccount(account1);
        bank.AddAccount(account2);
        bank.AddAccount(account3);

        bank.DisplayBankInfo();
        Console.WriteLine();

        bank.DepositToAccount("1234567890", 500);
        bank.WithdrawFromAccount("9876543210", 200);
        bank.WithdrawFromAccount("5678901234", 3000);

        Console.WriteLine();

        bank.DisplayBankInfo();

        bank.ExecuteTransaction("1234567890", 500);
        bank.ExecuteTransaction("9876543210", -200);
        bank.ExecuteTransaction("5678901234", -3000);

        Console.WriteLine();

        bank.PrintTransaction("1234567890");
        bank.PrintTransaction("9876543210");
        bank.PrintTransaction("5678901234");

        Console.ReadLine();
    }
}

